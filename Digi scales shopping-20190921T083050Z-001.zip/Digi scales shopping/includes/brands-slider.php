<div id="brands-carousel" class="logo-slider wow fadeInUp">
		<h3 class="section-title">Our Partners</h3>
		<div class="logo-slider-inner">
			<div id="brand-slider" class="owl-carousel brand-slider custom-carousel owl-theme">
				<div class="item">
					<a href="#" class="image">
						<img data-echo="brandsimages/1.jpg" src="assets/images/blank.gif" alt="">
					</a>
				</div><!--/.item-->

				<div class="item">
					<a href="#" class="image">
						<img data-echo="brandsimages/2.png" src="assets/images/blank.gif" alt="">
					</a>
				</div><!--/.item-->

				<div class="item">
					<a href="#" class="image">
						<img data-echo="brandsimages/3.jpg" src="assets/images/blank.gif" alt="">
					</a>
				</div><!--/.item-->

				<div class="item">
					<a href="#" class="image">
						<img data-echo="brandsimages/4.jpg" src="assets/images/blank.gif" alt="">
					</a>
				</div>

				<div class="item">
					<a href="#" class="image">
						<img data-echo="brandsimages/5.jpg" src="assets/images/blank.gif" alt="">
					</a>
				</div>

				<div class="item">
					<a href="#" class="image">
						<img data-echo="brandsimages/7.jpg" src="assets/images/blank.gif" alt="">
					</a>
				</div>

				<div class="item">
					<a href="#" class="image">
						<img data-echo="brandsimages/8.jpg" src="assets/images/blank.gif" alt="">
					</a>
				</div>

				<div class="item">
					<a href="#" class="image">
						<img data-echo="brandsimages/9.jpg" src="assets/images/blank.gif" alt="">
					</a>
				</div>

				<div class="item">
					<a href="#" class="image">
						<img data-echo="brandsimage/sony1.jpg" src="assets/images/blank.gif" alt="">
					</a>
				</div>

				<div class="item">
					<a href="#" class="image">
						<img data-echo="brandsimage/voltas1.jpg" src="assets/images/blank.gif" alt="">
					</a>
				</div>

				<div class="item">
					<a href="#" class="image">
						<img data-echo="brandsimage/lg1.jpg" src="assets/images/blank.gif" alt="">
					</a>
				</div>

				<div class="item">
					<a href="#" class="image">
						<img data-echo="brandsimage/lenovo1.jpg" src="assets/images/blank.gif" alt="">
					</a>
				</div>




		    </div><!-- /.owl-carousel #logo-slider -->
		</div><!-- /.logo-slider-inner -->

</div><!-- /.logo-slider -->
